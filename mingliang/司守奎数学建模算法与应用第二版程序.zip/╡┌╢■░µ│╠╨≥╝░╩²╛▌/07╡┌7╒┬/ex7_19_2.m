clc, clear
load xydata
rstool(x123,Y)
