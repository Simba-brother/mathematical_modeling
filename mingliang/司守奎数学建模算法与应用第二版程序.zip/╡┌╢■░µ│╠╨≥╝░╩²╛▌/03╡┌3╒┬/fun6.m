function f=fun6(x);
f=(x-3)^2-1;
